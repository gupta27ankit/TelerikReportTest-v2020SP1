namespace ReportLibrary1
{
	partial class Report1
	{
		#region Component Designer generated code
		/// <summary>
		/// Required method for telerik Reporting designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            Telerik.Reporting.Drawing.StyleRule styleRule1 = new Telerik.Reporting.Drawing.StyleRule();
            this.pageHeaderSection1 = new Telerik.Reporting.PageHeaderSection();
            this.detail = new Telerik.Reporting.DetailSection();
            this.pageFooterSection1 = new Telerik.Reporting.PageFooterSection();
            this.panel1 = new Telerik.Reporting.Panel();
            this.tb1 = new Telerik.Reporting.TextBox();
            this.panel4 = new Telerik.Reporting.Panel();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // pageHeaderSection1
            // 
            this.pageHeaderSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(4.4D);
            this.pageHeaderSection1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.panel1});
            this.pageHeaderSection1.Name = "pageHeaderSection1";
            this.pageHeaderSection1.ItemDataBinding += new System.EventHandler(this.pageHeaderSection1_ItemDataBinding);
            // 
            // detail
            // 
            this.detail.Height = Telerik.Reporting.Drawing.Unit.Cm(5D);
            this.detail.Name = "detail";
            // 
            // pageFooterSection1
            // 
            this.pageFooterSection1.Height = Telerik.Reporting.Drawing.Unit.Cm(2.5D);
            this.pageFooterSection1.Name = "pageFooterSection1";
            // 
            // panel1
            // 
            this.panel1.Docking = Telerik.Reporting.DockingStyle.Top;
            this.panel1.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.tb1,
            this.panel4});
            this.panel1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.panel1.Name = "panel1";
            this.panel1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(18.92D), Telerik.Reporting.Drawing.Unit.Cm(3.4D));
            this.panel1.Style.BorderStyle.Default = Telerik.Reporting.Drawing.BorderType.Solid;
            this.panel1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.6D);
            // 
            // tb1
            // 
            this.tb1.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(6.27D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.tb1.Name = "tb1";
            this.tb1.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(12.65D), Telerik.Reporting.Drawing.Unit.Cm(0.8D));
            this.tb1.Style.BackgroundColor = System.Drawing.Color.Empty;
            this.tb1.Style.BackgroundImage.MimeType = "image/png";
            this.tb1.Style.BorderStyle.Bottom = Telerik.Reporting.Drawing.BorderType.Solid;
            this.tb1.Style.BorderStyle.Left = Telerik.Reporting.Drawing.BorderType.None;
            this.tb1.Style.BorderWidth.Bottom = Telerik.Reporting.Drawing.Unit.Point(0.6D);
            this.tb1.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.6D);
            this.tb1.Style.BorderWidth.Left = Telerik.Reporting.Drawing.Unit.Point(0.6D);
            this.tb1.Style.BorderWidth.Right = Telerik.Reporting.Drawing.Unit.Point(0.6D);
            this.tb1.Style.BorderWidth.Top = Telerik.Reporting.Drawing.Unit.Point(0.6D);
            this.tb1.Style.Font.Bold = true;
            this.tb1.Style.Font.Name = "Microsoft Sans Serif";
            this.tb1.Style.Font.Size = Telerik.Reporting.Drawing.Unit.Point(12D);
            this.tb1.Style.TextAlign = Telerik.Reporting.Drawing.HorizontalAlign.Center;
            this.tb1.StyleName = "PageInfo";
            this.tb1.Value = "";
            // 
            // panel4
            // 
            this.panel4.Location = new Telerik.Reporting.Drawing.PointU(Telerik.Reporting.Drawing.Unit.Cm(0D), Telerik.Reporting.Drawing.Unit.Cm(0D));
            this.panel4.Name = "panel4";
            this.panel4.Size = new Telerik.Reporting.Drawing.SizeU(Telerik.Reporting.Drawing.Unit.Cm(6.26D), Telerik.Reporting.Drawing.Unit.Cm(3.4D));
            this.panel4.Style.BorderStyle.Right = Telerik.Reporting.Drawing.BorderType.Solid;
            this.panel4.Style.BorderWidth.Default = Telerik.Reporting.Drawing.Unit.Point(0.6D);
            // 
            // Report1
            // 
            this.Items.AddRange(new Telerik.Reporting.ReportItemBase[] {
            this.pageHeaderSection1,
            this.detail,
            this.pageFooterSection1});
            this.Name = "Report1";
            this.PageSettings.Margins = new Telerik.Reporting.Drawing.MarginsU(Telerik.Reporting.Drawing.Unit.Mm(20D), Telerik.Reporting.Drawing.Unit.Mm(20D), Telerik.Reporting.Drawing.Unit.Mm(20D), Telerik.Reporting.Drawing.Unit.Mm(20D));
            this.PageSettings.PaperKind = System.Drawing.Printing.PaperKind.A4;
            styleRule1.Selectors.AddRange(new Telerik.Reporting.Drawing.ISelector[] {
            new Telerik.Reporting.Drawing.TypeSelector(typeof(Telerik.Reporting.TextItemBase)),
            new Telerik.Reporting.Drawing.TypeSelector(typeof(Telerik.Reporting.HtmlTextBox))});
            styleRule1.Style.Padding.Left = Telerik.Reporting.Drawing.Unit.Point(2D);
            styleRule1.Style.Padding.Right = Telerik.Reporting.Drawing.Unit.Point(2D);
            this.StyleSheet.AddRange(new Telerik.Reporting.Drawing.StyleRule[] {
            styleRule1});
            this.Width = Telerik.Reporting.Drawing.Unit.Cm(18.92D);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

            }
		#endregion
		
		private Telerik.Reporting.PageHeaderSection pageHeaderSection1;
		private Telerik.Reporting.DetailSection detail;
		private Telerik.Reporting.PageFooterSection pageFooterSection1;
        private Telerik.Reporting.Panel panel1;
        private Telerik.Reporting.TextBox tb1;
        private Telerik.Reporting.Panel panel4;
    }
}