﻿using System;
using System.IO;
using Telerik.Reporting.Processing;

namespace WebApplication2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var report = new ReportLibrary1.Report1();
            ReportProcessor reportProcessor = new ReportProcessor();
            RenderingResult result = reportProcessor.RenderReport("PDF", report, null);

            FileStream fs = new FileStream(result.DocumentName, FileMode.Create);
            fs.Write(result.DocumentBytes, 0, result.DocumentBytes.Length);
            fs.Close();
        }
    }
}