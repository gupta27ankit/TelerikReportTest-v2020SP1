namespace ReportLibrary1
{
    using System;

    /// <summary>
    /// Summary description for Report1.
    /// </summary>
    public partial class Report1 : Telerik.Reporting.Report
    {
        public Report1()
        {
            InitializeComponent();
        }

        private void pageHeaderSection1_ItemDataBinding(object sender, EventArgs e)
        {
            tb1.Value = "123456789012345678901234567890123456789012345678901234567890";
        }
    }
}